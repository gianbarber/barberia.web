
emailjs.init("Ms-un1HcwDE_IKVtZ"); // Tu Public Key de EmailJS

document.getElementById("formReserva").addEventListener("submit", function(event) {
  event.preventDefault();

  const form = event.target;

  emailjs.send("service_lbb0a1q", "template_5s9cj8v", {
    nombre: form.nombre.value,
    telefono: form.telefono.value,
    servicio: form.servicio.value,
    fecha: form.fecha.value
  })
  .then(function() {
    document.getElementById("confirmacion").style.display = "block";
  }, function(error) {
    alert("Hubo un error al enviar la reserva. Intenta nuevamente.");
    console.log(error);
  });
});
